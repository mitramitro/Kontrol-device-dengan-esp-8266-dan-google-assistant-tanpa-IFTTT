const express = require("express");
const bodyParser = require("body-parser");

const { conversation, Image } = require("@assistant/conversation");

// Create an app instance
const app = conversation();
const port = 3000;
const axios = require("axios");

// Register handlers for Actions SDK

app.handle("devicecontrol", (conv) => {
  const device_name = conv.intent.params.device_name_1.resolved;
  console.log(device_name);

  const device_status = conv.intent.params.device_status_1.resolved;
  console.log(device_status);

  if (device_name == "kipas" && device_status == "on") {
    getOn("D0/0");
  } else if (device_name == "kipas" && device_status == "off") {
    getOn("D0/1");
  } else if (device_name == "lampu" && device_status == "on") {
    getOn("D1/0");
  } else if (device_name == "lampu" && device_status == "off") {
    getOn("D1/1");
  }
  //   conv.add("Hi, how is it going?");
  //   conv.add(
  //     new Image({
  //       url: "https://developers.google.com/web/fundamentals/accessibility/semantics-builtin/imgs/160204193356-01-cat-500.jpg",
  //       alt: "A cat"
  //     })
  //   );
});

async function getOn(url) {
  try {
    const response = await axios.get("http://192.168.0.21/" + url);
    console.log(response);
  } catch (error) {
    console.error(error);
  }
}

const expressApp = express().use(bodyParser.json());

expressApp.post("/fulfillment", app);

expressApp.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
